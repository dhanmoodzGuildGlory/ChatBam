Reserved for original ChatBam SVG assets. The current preview uses Material icons as placeholders; replace them with authored SVGs in the design pass.
