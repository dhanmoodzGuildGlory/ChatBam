# ChatBam — Jester-inspired UI foundation

This is the first implementation milestone, not a finished app and not a claim of 100% parity.

## Reference mapping captured from the supplied Jester recording
- Login / register and success transition
- Home: profile banner, wallet/summary area (ChatBam replaces Wallet with Role), online friends, global chat entry
- Global Chat: message bubbles and composer
- Music downloads / now playing
- Profile and settings

## Included
- Original ChatBam asset pack extracted from `bahan bahan image chatbam.zip`
- Flutter UI foundation for Home, Global Chat, Music, and Profile
- SVG navigation/drawer icon assets
- Dark purple/neon design tokens and reusable glow card

## Run/build
Requires Flutter 3.22+ and Android SDK:
1. `flutter pub get`
2. `flutter run`
3. For a universal APK: `flutter build apk --release`

## Important unfinished work
- Authentication and Firebase connection
- Real-time backend chat, presence, read receipts, friend requests
- Role authorization enforced by trusted backend
- Music catalog/streaming integration
- Push notifications and moderation
- Full screen-by-screen parity pass against the Jester recording
- Intro video playback and update delivery flow

Do not ship this build as production. Chat messages are local demo state only.

## Jester-inspired UI revision
This is a visual prototype using ChatBam-owned assets and a dark neon-purple style inspired by the supplied Jester recording. It adds a login/register entry screen, a Jester-like grouped drawer, home dashboard cards, global chat bubbles/composer, download list and now-playing layout, and profile/settings/avatar selection. It is not an exact clone and no similarity percentage has been verified. Sample login, UID, messages, music and online status are placeholders. No authentication, live backend, push notifications, moderation, music streaming or server-side role checks are connected.


## Additional screen set
Added Friends (requests and list), Shop, Role, Notifications, and Settings screen layouts. These are visual mockups only; actions, purchases, role enforcement, and notifications are not backed by a server yet.
